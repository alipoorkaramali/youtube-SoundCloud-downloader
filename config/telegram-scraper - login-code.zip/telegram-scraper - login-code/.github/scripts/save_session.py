#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys, json
from pathlib import Path
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout

PROFILE_DIR = Path("config/browser_profile")
TARGET_URL = "https://web.telegram.org/a/"

def main():
    if PROFILE_DIR.exists() and any(PROFILE_DIR.iterdir()):
        print("⚠️ browser_profile folder already exists.")
        ans = input("Continue with the same profile? (y/n)").strip().lower()
        if ans != 'y':
            print("Please delete the folder and run again.")
            sys.exit(0)

    with sync_playwright() as p:
        try:
            context = p.chromium.launch_persistent_context(
                user_data_dir=str(PROFILE_DIR),
                channel="chrome",
                headless=False,
                viewport={"width": 1280, "height": 900},
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ..."
            )
            print("✅ Chrome launched.")
        except Exception as e:
            print(f"❌ Error launching browser: {e}")
            sys.exit(1)

        page = context.pages[0] if context.pages else context.new_page()

        try:
            page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=60000)
        except PlaywrightTimeout:
            print("❌ Page didn't load. Please check your VPN.")
            context.close()
            sys.exit(1)

        print("\n📱 **Now please log in to Telegram completely** (phone number, verification code, 2FA password)")
        print("  Press ENTER here after you see the chat list...\n")
        input("⌨️ Press Enter to continue the script: ")

        # ⚡️ بررسی localStorage به جای selector
        logged_in = page.evaluate('''() => {
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key && (key.includes('auth_key') || key.includes('session') || key.includes('user'))) {
                    return true;
                }
            }
            return false;
        }''')

        if logged_in:
            print("✅ Confirmed: You are logged into Telegram.")
        else:
            # یک اسکرین‌شات برای عیب‌یابی
            screenshot_path = PROFILE_DIR.parent / "login_failed.png"
            page.screenshot(path=str(screenshot_path))
            print(f"❌ You are not logged in! Screenshot saved at {screenshot_path}.")
            print("Please check the screenshot. If you actually see the chats, the Telegram version may have changed.")
            context.close()
            sys.exit(1)

        # ذخیره پروفایل (در واقع همین‌جا که context بسته شود، خودکار ذخیره می‌شود)
        context.close()
        print("✅ Valid profile saved in config/browser_profile.")
        print("Now you can compress the folder and upload to GitHub:")
        print("  tar -czf config/browser_profile.tar.gz -C config browser_profile")

if __name__ == "__main__":
    main()